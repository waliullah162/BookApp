package com.example.bookapp.networkRelatedClass;

import com.example.bookapp.model.ServerResponse;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface{

    @GET("/v2/list")
    Call<ServerResponse> getImageListFromServer();

}
