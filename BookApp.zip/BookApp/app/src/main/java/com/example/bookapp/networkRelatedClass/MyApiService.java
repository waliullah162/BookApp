package com.example.bookapp.networkRelatedClass;

public interface MyApiService {

    void getImageListFromServer(ResponseCallback<String>callback);
}
