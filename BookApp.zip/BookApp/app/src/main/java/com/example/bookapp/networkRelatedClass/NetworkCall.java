package com.example.bookapp.networkRelatedClass;

import android.widget.Toast;

import com.example.bookapp.model.ServerResponse;
import com.example.bookapp.view.MainActivity;
import com.google.gson.annotations.SerializedName;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NetworkCall implements MyApiService {

    @Override
    public void getImageListFromServer(final ResponseCallback<String>callbackListener) {

        ApiInterface retrofitApiInterface=RetrofitApiClient.getClient().create(ApiInterface.class);
        Call<ServerResponse> call=retrofitApiInterface.getImageListFromServer();

        call.enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {

              ServerResponse validity=response.body();


            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {

            }
        });

    }
}
