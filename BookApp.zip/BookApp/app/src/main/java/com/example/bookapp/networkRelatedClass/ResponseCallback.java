package com.example.bookapp.networkRelatedClass;

public interface ResponseCallback<T> {

    void onSuccess(T data);
    void onError(Throwable th);


}
