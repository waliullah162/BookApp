package com.example.bookapp.adapter;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.bookapp.R;
import com.example.bookapp.model.ServerResponse;

import java.util.List;

public class GridViewAdapter extends BaseAdapter {


    List<ServerResponse>imageList;

    public GridViewAdapter(List<ServerResponse> imageList) {
        this.imageList = imageList;
    }

    @Override
    public int getCount() {
        return imageList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view;
        ImageView imageView;
        TextView textView;

        if(convertView==null){

           view= LayoutInflater.from(parent.getContext()).inflate(R.layout.sample_layout,null);

           imageView=view.findViewById(R.id.bookImageView);
           textView=view.findViewById(R.id.authorName);

           Uri imageUri=Uri.parse(imageList.get(position).getUrl());
           imageView.setImageURI(imageUri);

           textView.setText(imageList.get(position).getAuthorName());



        }
        else{

            view=convertView;
        }

        return view;
    }
}
