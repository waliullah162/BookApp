package com.example.bookapp.view;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.GridView;

import com.example.bookapp.R;
import com.example.bookapp.adapter.GridViewAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import retrofit2.http.Url;

public class MainActivity extends AppCompatActivity {

    private List<String> imageList;
    private GridView gridView;
    private GridViewAdapter gridViewAdapter;

    private static String url="https://picsum.photos/v2/list";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageList=new ArrayList<String>();
        gridView=findViewById(R.id.gridView);


        try {
            //Since we have JSON Object so we are getting the object
            //Here we are calling a function and that function is returning the JSON object
            JSONObject jsonObject=new JSONObject(url);

            //Fetch JSONArray named users by using getJSONArray
            JSONArray userArray=jsonObject.getJSONArray("array");

            //Implement for loop for getting users data i.e name,email and contact
            for(int i=0;i<userArray.length();i++){
                //create a JSONObject for fetching single object data
                JSONObject imageDetails=userArray.getJSONObject(i);

                //fetch email and name and store it in arrayList
                String authorName=imageDetails.getString("authorName");
                imageList.add(authorName);

               // Url imageUrl=imageDetails.("email");
                //emailIds.add(email);

                //Uri imageUri=imageDetails.getString().getU

                String imageUrl=imageDetails.getString("image");
                imageList.add(imageUrl);

                //Create a object for getting contact data from JSONObject
                //
                //
                // JSONObject contact=userDetails.getJSONObject("contact");

                //fetch mobile number 1 and store it in arrayList of mobileNumber
                //mobileNumbers.add(contact.getString("mobile1"));

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        gridViewAdapter = new GridViewAdapter(imageList);



        gridView.setAdapter(gridViewAdapter);


        //prepare data
        //data will come from server through Api




        gridViewAdapter.notifyDataSetChanged();

    }


}